import React from 'react';
import Welcome from './componentes/Welcome';
import './App.css';

function App(){
    return(
        <>
            <Welcome name="Jean"/>
        </>
    );
}

export default App;